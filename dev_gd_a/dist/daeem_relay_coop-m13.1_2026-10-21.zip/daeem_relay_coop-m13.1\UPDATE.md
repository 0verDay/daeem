# DAEEM 合作中继服务端 · coop-m13.1

打包日期：2026-10-21
适用：Windows + Python 3.11+ + nssm（与 `server/README.md` 一致）

## 包里有什么

| 文件 | 用途 |
|---|---|
| `daeem_relay.py` | **真正要替换的服务端**（零第三方依赖，只用 Python 标准库） |
| `deploy.ps1` | 推荐：自动备份 / 停服务 / 替换 / 重启 / 健康检查，失败自动回滚 |
| `README.md` | 服务端部署与协议说明 |
| `probe_relay.py` + `relay_client.py` | 本机 host/guest 联机探针 |
| `run-local.ps1` | 一条命令跑中继 + 双探针（本机自测） |
| `test_relay.py` | 中继单元测试 |

> 部署时**只需要替换 `daeem_relay.py`**；`deploy.ps1` 也只会复制 `daeem_relay.py` 与 `README.md`，不会碰 `logs/`、`backup/` 或 IIS。

## 方式 A：用 deploy.ps1 替换（推荐）

1. 把 zip 解压到服务器上，例如：
   `C:\daeem_stage\daeem_relay_coop-m13.1\`
2. 以**管理员**身份打开 PowerShell，先空跑确认参数：
   ```powershell
   powershell -ExecutionPolicy Bypass -File C:\daeem_stage\daeem_relay_coop-m13.1\deploy.ps1 `
       -ServerRoot C:\daeem `
       -Python "C:\Program Files\python\python.exe" `
       -Nssm C:\tools\nssm.exe `
       -Build coop-m13.1 `
       -PublicIp <服务器公网IP> `
       -DryRun
   ```
3. 确认无误后，去掉 `-DryRun` 再执行一次。
   脚本会：备份 `C:\daeem\server` → 停 `DAEEMRelay` → 复制新 `daeem_relay.py` / `README.md` → 启动服务 → 轮询 `/health`；失败会自动恢复备份。
4. 验证：
   ```powershell
   curl http://<服务器公网IP>:8770/health
   curl http://<服务器公网IP>:8770/rooms
   ```
   `/health` 里应看到 `"build":"coop-m13.1"`。

## 方式 B：手工替换（不想跑脚本）

1. 先停服务：
   ```powershell
   nssm stop DAEEMRelay
   ```
2. 备份：
   ```powershell
   Copy-Item C:\daeem\server C:\daeem\backup\server-before-m13.1 -Recurse -Force
   ```
3. 覆盖运行文件：
   ```powershell
   Copy-Item C:\daeem_stage\daeem_relay_coop-m13.1\daeem_relay.py `
       C:\daeem\server\daeem_relay.py -Force
   Copy-Item C:\daeem_stage\daeem_relay_coop-m13.1\README.md `
       C:\daeem\server\README.md -Force
   ```
4. 启动：
   ```powershell
   nssm start DAEEMRelay
   ```
5. 检查：
   ```powershell
   curl http://127.0.0.1:8770/health
   ```
   必须是 `coop-m13.1`，否则客户端会被 build 校验拒绝。

## 回滚

- 用 `deploy.ps1` 的：它会自动生成 `C:\daeem\backup\server-<时间戳>`，失败自动恢复；也可手动把备份目录复制回 `C:\daeem\server` 后重启服务。
- 手工替换的：把上面第 2 步备份里的 `daeem_relay.py` 复制回 `C:\daeem\server`，再 `nssm start DAEEMRelay`。

## 注意

- 这次替换包含协议升级：客户端必须是支持 `coop-m13.1` 的版本；旧客户端会被拒绝。
- 数字房间码是 6 位 0-9，旧字母码不再有效。
- 不需要 `pip install`，也不需要改端口 / IIS；TCP 8770 的云安全组保持原样。
- 服务端日志仍在 `C:\daeem\logs\relay.{out,err}.log`，不会被覆盖。
